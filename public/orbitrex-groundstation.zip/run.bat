@echo off
echo ========================================================
echo   ORBITREX CubeSat Ground Station Launcher (Windows)
echo ========================================================
echo.

if not exist node_modules (
  echo [1/3] First-time setup: Installing dependencies...
  call npm install
  if errorlevel 1 (
    echo [ERROR] npm install failed. Make sure Node.js is installed from https://nodejs.org
    pause
    exit /b
  )
)

echo [2/3] Opening Mission Control in default browser...
start http://localhost:3000

echo [3/3] Starting Ground Station Server (WebSocket + USB Serial)...
echo Press Ctrl+C in this window to stop the server.
echo.
node server.js
pause
