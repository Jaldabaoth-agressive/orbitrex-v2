================================================================================
ORBITREX CUBESAT GROUND STATION - SETUP & QUICK START GUIDE
================================================================================

IMPORTANT NOTE FOR WINDOWS USERS:
"Could not find the item" Error:
If you double-click files directly from inside the ZIP file without extracting,
Windows will show: "Could not find this item. This is no longer located in..."
To fix this:
  1. Right-click the downloaded ZIP file.
  2. Click "Extract All..." (or unzip with 7-Zip / WinRAR).
  3. Choose a destination folder (e.g. Desktop or Documents) and click Extract.
  4. Now open the extracted folder and follow the steps below!

--------------------------------------------------------------------------------
OPTION A: INSTANT OFFLINE RUN (No server or terminal needed)
--------------------------------------------------------------------------------
1. In the extracted folder, double-click "public/index.html".
2. It opens directly in Chrome, Edge, Safari, or Firefox with the complete
   interactive Mission Dashboard, 3D attitude cuboid model, and SVG charts!

--------------------------------------------------------------------------------
OPTION B: FULL HARDWARE GROUND STATION (With ESP32 USB Serial & WebSockets)
--------------------------------------------------------------------------------
Prerequisites:
  - Install Node.js (v18 or higher) from https://nodejs.org (LTS recommended)
  - Arduino IDE to flash your ESP32 boards

Step 1: Flash the 2nd ESP32 Bridge
  - Open "arduino/ESP32_Bridge_Receiver.ino" in Arduino IDE.
  - Connect your 2nd ESP32 to your computer via USB.
  - Flash the sketch and open Serial Monitor at 115200 baud.
  - Verify the printed MAC address matches the 'receiverMAC[]' on your CubeSat.

Step 2: Start the Ground Station Server
  - Windows: Double-click "run.bat"
  - Mac / Linux: Run chmod +x run.sh && ./run.sh
  - OR open your terminal in this folder and run:
      npm install
      node server.js

Step 3: Open Mission Control
  - Navigate to http://localhost:3000 in your browser.
  - The dashboard will connect via WebSocket automatically!

--------------------------------------------------------------------------------
API ENDPOINTS:
--------------------------------------------------------------------------------
  - GET  /api/status          Server uptime and connection status
  - GET  /api/history         Last 50 recorded telemetry packets
  - POST /api/telemetry       Ingest raw telemetry packet (JSON or CSV)
  - GET  /api/serial/ports    List available computer COM ports
================================================================================
