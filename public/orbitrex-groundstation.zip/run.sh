#!/bin/bash
echo "========================================================"
echo "  ORBITREX CubeSat Ground Station Launcher (Mac/Linux)"
echo "========================================================"
echo ""

if [ ! -d "node_modules" ]; then
  echo "[1/3] First-time setup: Installing dependencies..."
  npm install
  if [ $? -ne 0 ]; then
    echo "[ERROR] npm install failed. Make sure Node.js is installed."
    exit 1
  fi
fi

echo "[2/3] Opening browser at http://localhost:3000..."
if which xdg-open > /dev/null; then
  xdg-open http://localhost:3000 &
elif which open > /dev/null; then
  open http://localhost:3000 &
fi

echo "[3/3] Starting Ground Station Server..."
node server.js
